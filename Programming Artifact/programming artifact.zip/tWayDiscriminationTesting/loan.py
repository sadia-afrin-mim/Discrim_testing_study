import sys
gender = sys.argv[1]
race = sys.argv[2]
income = sys.argv[3]

# first case
if gender == "gen1":
	print ("1")
elif race != "green":
	if income == "0...50000":
		print ("0")
	else:
		print ("1")
else:
	if income == "0...50000" or income == "50001...100000":
		print ("0")
	else:
		print ("1")



