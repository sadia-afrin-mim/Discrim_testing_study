import pandas as pd
import numpy as np
import subprocess
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from itertools import product

# ── 1. Train logistic regression on biased dataset ─────────────────────────────
df = pd.read_csv("adult_biased_200.csv")

df_model = df.copy()
le_edu  = LabelEncoder()
le_race = LabelEncoder()
le_sex  = LabelEncoder()

df_model['education-num'] = le_edu.fit_transform(df_model['education-num'])
df_model['race']          = le_race.fit_transform(df_model['race'])
df_model['sex']           = le_sex.fit_transform(df_model['sex'])

features = ['age', 'education-num', 'race', 'sex',
            'capital-gain', 'capital-loss', 'hours-per-week']
X = df_model[features]
y = df_model['pred_label']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42)

model = LogisticRegression(max_iter=1000, random_state=42)
model.fit(X_train, y_train)

print("=" * 60)
print("MODEL PERFORMANCE")
print("=" * 60)
print(f"  Accuracy : {accuracy_score(y_test, model.predict(X_test)):.2f}")
print(classification_report(y_test, model.predict(X_test)))

# ── 2. Generate ACTS test cases for protected attributes only ──────────────────
print("=" * 60)
print("GENERATING ACTS TEST CASES (protected attributes only)")
print("=" * 60)

subprocess.call([
    'java', '-Dalgo=ipog', '-Ddoi=2', '-Doutput=csv',
    '-jar', 'ACTS3/acts_3.0.jar',
    'Data/ACTS_param/adult.txt',
    'Data/tWay_Abstract_TC/adult_protected_combos.csv'
])

# ── 3. Load protected attribute combinations from ACTS ─────────────────────────
tc = pd.read_csv("Data/tWay_Abstract_TC/adult_protected_combos.csv", comment="#")
tc.columns = [c.strip().lower() for c in tc.columns]
print(f"  ACTS generated {len(tc)} protected attribute combinations")
print(tc)

# ── 4. Define fixed non-protected attribute values ─────────────────────────────
non_protected_configs = [
    {'age': 20, 'education-num': le_edu.transform(['HS-grad'])[0],
     'capital-gain': 0, 'capital-loss': 0, 'hours-per-week': 40},

    {'age': 40, 'education-num': le_edu.transform(['Bachelors'])[0],
     'capital-gain': 0, 'capital-loss': 0, 'hours-per-week': 40},

    {'age': 60, 'education-num': le_edu.transform(['Masters'])[0],
     'capital-gain': 0, 'capital-loss': 0, 'hours-per-week': 40},
]

# ── 5. Build test cases: each non-protected config x each protected combo ───────
rows = []
for np_config in non_protected_configs:
    for _, prot_row in tc.iterrows():
        row = {
            'race_label'    : prot_row['race'],
            'sex_label'     : prot_row['sex'],
            'race'          : le_race.transform([prot_row['race']])[0],
            'sex'           : le_sex.transform([prot_row['sex']])[0],
            **np_config
        }
        rows.append(row)

tc_concrete = pd.DataFrame(rows)
tc_concrete['prediction'] = model.predict(tc_concrete[features])

print(f"\n  Total test cases (protected combos x non-protected configs): {len(tc_concrete)}")

# ── 6. Discrimination analysis — gender ────────────────────────────────────────
print("\n" + "=" * 60)
print("DISCRIMINATION ANALYSIS — GENDER")
print("=" * 60)

for gender in tc_concrete['sex_label'].unique():
    g    = tc_concrete[tc_concrete['sex_label'] == gender]
    rate = g['prediction'].mean() * 100
    bar  = "█" * int(rate / 5)
    print(f"  {gender:<8} approval rate : {rate:5.1f}%  ({int(g['prediction'].sum())} of {len(g)})  {bar}")

gen_rates = tc_concrete.groupby('sex_label')['prediction'].mean() * 100
print(f"\n  Max gender disparity : {gen_rates.max() - gen_rates.min():.1f}%")

# ── 7. Discrimination analysis — race ─────────────────────────────────────────
print("\n" + "=" * 60)
print("DISCRIMINATION ANALYSIS — RACE")
print("=" * 60)

for race in tc_concrete['race_label'].unique():
    r    = tc_concrete[tc_concrete['race_label'] == race]
    rate = r['prediction'].mean() * 100
    bar  = "█" * int(rate / 5)
    print(f"  {race:<8} approval rate : {rate:5.1f}%  ({int(r['prediction'].sum())} of {len(r)})  {bar}")

race_rates = tc_concrete.groupby('race_label')['prediction'].mean() * 100
print(f"\n  Max race disparity : {race_rates.max() - race_rates.min():.1f}%")

# ── 8. Race x Gender breakdown ─────────────────────────────────────────────────
print("\n" + "=" * 60)
print("DISCRIMINATION ANALYSIS — RACE x GENDER")
print("=" * 60)

for race in tc_concrete['race_label'].unique():
    print(f"\n  {race.upper()}:")
    for gender in tc_concrete['sex_label'].unique():
        g = tc_concrete[
            (tc_concrete['race_label'] == race) &
            (tc_concrete['sex_label']  == gender)
        ]
        if len(g) > 0:
            rate = g['prediction'].mean() * 100
            bar  = "█" * int(rate / 10)
            print(f"    {gender:<8} {rate:5.1f}%  ({int(g['prediction'].sum())} of {len(g)})  {bar}")

# ── 10. Save results ───────────────────────────────────────────────────────────
tc_concrete.to_csv("Data/tWay_Abstract_TC/adult_2way.csv", index=False)
print("\n  Full results saved to: Data/tWay_Abstract_TC/adult_2way.csv")
